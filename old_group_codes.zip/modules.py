# from tasks import sum_two_number, MAX_VALUE, apple
# from tasks import *
# from tasks import (
#     sum_two_number,
#     MAX_VALUE,
#     apple
# )
# sum_two_number(10,20)
# print(MAX_VALUE)
# print(apple)


# import datetime as dt
#
# print(dt.datetime.now())

# import time, math
# print(time.strftime("%d:%m:%Y"))
# print(math.pi)


# if __name__ == '__main__':
#     print("Bu asosiy dastur")
# else:
#     print("Import qilingan modul")

# def deco(f):
#     print("func() chaqirildi")
#     return f
#
# @deco
# def func(x):
#     def main(num):
#         print(num**2)
#     main(x)
#     return f"x = {x}"
#
# print(func(10))