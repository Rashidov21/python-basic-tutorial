# list() >> array
# len() >> lenght int

# def <fuknsiya nomi>([parametrlar]):
#     ["""Funksiyani documentataion"""]
#     <Funksiyani tanasi>
#     [return <Natija>]

# def printOk():
#     """This is my first function in Python"""
#     print("Ok")
# # print(printOk())
# printOk()

# def func():
#     pass
#

# def echo():
#     print("echo hello world")
# echo()  # funksiyani chaqirish



# def plus(x,y):
#     return x + y
# print(plus(20,10))

# def getUserShortname(name,surname):
#     return name + " " + surname
# r = getUserShortname("Abdurahmon","Rashidov")
# print(r)

# def getMaxValue(arr):
#     return max(arr)
# m = getMaxValue([2,6,7,8,9])
# print(m)
# def userInfo(name,surname, age=0):
#     return name + " " + surname + " " +  str(age)
# print(userInfo("ali", 'vali', 12))
# num = 10
# print(num)
# def func(x):
#     return print(x * 2)
# func(num)
# def func(x,y):
#     return print( x ** y )
# func(x=10,y=2)


# def plus(a,b=0):
#     return a+b
# print(plus(10))
# def main(param1=10): # deafult params , doimiy qiymatlar
#     print(param1)
# main()

# x,y,*z = [1,2,3,4,5,6]
# print(x,y,z) #1 2 [3, 4, 5, 6]

# *args
# bitta * lik metod bu berilayotgan argumentlarni tuple ga joyledi
# def summa(*args):
#     """ funksiya nomalum miqdorda qiymat qabul qiladi """
#     print(type(args))
#     res = 0
#     for i in args:
#         res += 1
#     return res
# #
# # print(summa(10,20))
# print(summa(10,20,30,40,50,60))

# def summa(*args):
#     print(type(args)) # tuple
#     res = 0
#     for i in args:
#         res += 1
#     return res
# print(summa(1,2,3,4,5))
# def test(*args):
#     l = []
#     for i in args:
#         l.append(i**2)
#     return l
# t = test(1,2,3,4,5)
# print(t)

# **kwargs
#  ikita * lik metod bu berilayotgan argumentlarni dict ga joyledi

# def func(**kwargs):
#     print(type(kwargs))
#     for i in kwargs.items():
#         print(i)
# # func(a=1,b=2,c=3)
# func(abdullo="ishchi",oylik=15000,kun=13, tolandi=False)

# def func(**kwargs):# keyword arguments
#     print(kwargs)
#     for i in kwargs:
#         print(i)
# func(a=1,b=2,c=3)

# def superFunc(*args,**kwargs):
#     """ function istalgan argumentni qabul qila oladi"""
#     for i in args:
#         print(i, end="")
#     for j in kwargs.items():
#         print(j)
# superFunc(1,2,3,4,5, olti=6,yetti=7)

# f = lambda: 10 + 20
# print(f()) # 30
# f1 = lambda x,y: x + y
# print(f1(10,20))# 30
# f2 = lambda x,y=5:x * y
# print(f2(10)) # 50
# print(f2(10,2)) # 20
# def arrUp(arr):
#     l = lambda a:max(a)
#     return l(arr)
# print(arrUp([1,2,3,4,5]))
# arr = list(range(0,11))
# arr2 = []
# f = lambda x: x ** 2
# for i in arr:
#     arr2.append(f(i))
#
# print(arr2)

# Decorators
# Decorator bu biror bir funtionni ishlashiga tasir otqizadgan boshqa bir
# functionga aytiladi, masalan function ishga tushishidan avval biror bir
# ishni qilishi kerak bolsa decorator buni unga qildira oladi

# def deco(f):
#     print("f funksiyasi chaqirildi")
#     return f
# #
# @deco
# def func(x):
#     return f"x = {x}"
# print(func(10))

# password = input("parolni kirit..")
# def testPassword(p):
#     def deco(f):
#         if p == "10":
#             return f
#         else:
#             return lambda : "Sizga ruxsat yo'q !"
#     return deco
# @testPassword(password)
# def func():
#     return "Sizga ruxsat bor!"
#
# print(func())

# pin = input("PIN kodni kiriting..")
# def check_pinCode(pin):
#     def deco(f):
#         if pin == "1234":
#             return f
#         else:
#             return lambda : "Sizga ruxsat yo'q !"
#     return deco
#
# @check_pinCode(pin)
# def getMoney():
#     m = int(input("Qancha yechamiz ?"))
#     balance = 100
#     print("Chekni oling: balans=",balance-m)
# #
# @check_pinCode(pin)
# def addMoney():
#     m = int(input("Qancha solamiz ?"))
#     balance = 100
#     print("Chekni oling: balans=", balance + m)
#
# print(getMoney())
# print(addMoney())

# Rekursiya
# Rekursiya bu - biror bir functionni ozini ozi chaqiqirishia aytiladi

# def factorial(n):
#     if n == 0 or n == 1:
#         return 1
#     else:
#         return  n * factorial(n - 1) 5,4
# while True:
#     x = int(input("Sonni kiriting.."))
#     print(f"{x} ni faktoriali =  {factorial(x)}")

# task 1

# decorator orqali login va username togri bolgandagina saytga xush kelibsiz
# degan matnni print qiladgan function yozing

# task 2
# login va username tori boganda user dan son sorab uni factorialini
# hisoblaydigan function yozing

# task 3
# input: user  = "123456970"
# output: str  dagi barcha sonlarni bir biriga qoshin va agar 0 mavjud bolsa
# summani print qiling script toxtasin

# arr = [2,6,4,8,9,3,23,56,8,3,1]
# print(arr)
# arr.sort()
# print(arr)

# def main():
#     """Bu meni function im"""
#     print("Main func")
    
# x = 10
# print(dir(x))
# print(x.__doc__)
# print(main.__doc__)

# a = list(range(1,6))
# for i in map(lambda x:x*x, a):
#     print(i)

# def func(x,y):
#     for i in range(1, x+1):
#         yield i * y

# for x in func(10,2):
#     print(x)

# num = 5 # global

# def test(x):
#     global y 
#     y = 2 # local 
#     if True:
#         print(num)
#     return x * y
# print(test(num))
# print(y)
# import random, time, datetime
# # import time 
# # import math
# from ifelse import n
# print(n)
# # print(math.pi)
# from math import pi
# print(pi)
# arr = [10,23,-8,6,-1,0,2,3,7]
# N = len(arr)
# for i in range(N-1):
#     m = arr[i]
#     p = i
#     for j in range(i+1, N):
#         if m > arr[j]:
#             m = arr[j]
#             p = j
#     if p != arr[i]:
#         t = arr[i]
#         arr[i] = arr[p]
#         arr[p] = t
# print(arr)

# if __name__ == '__main__':
#     print("asosiy modul")
# else:
#     print("Import qilingan modul")
    