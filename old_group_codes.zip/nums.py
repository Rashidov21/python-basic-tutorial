import math
import random
# int , float , complex

# int , == 1,2,-9
# float , == 1.1, -99.3
# i = int("12") # type int 12
# f = float("12") # type float 12.0
# a = abs(-12) # 12
# print(a)
# n = 2.3
# print(math.floor(n)) # 66
# print(math.ceil(n)) # 67
# print(round(n)) #2
# print(pow(n , 2)) # 5.33
# print(min([1,2,3])) #1
# print(max([1,2,3])) # 3
# print(sum([1,2,3])) # 6

# print(math.pi) # 3.14

# RANDOM
# random.random() , shuffle , sample, choice, randint, randrange
# x = random.randrange(0,10)
# print(x)