# -*- coding: utf-8 -*-
import math
"""/// Numbers ///"""
# n = "12" #str
# y = int(n)
# z = str(y)
# n = 12.3
#print(round(n)) # 12 butun sonni qaytaryapti
# n = 12.7
#print(round(n)) # 13 butun sonni qaytaryapti

# n = 12.1
# print(abs(n)) # absolut qiymatini qaytaradi

# print(max(1,3,8)) # eng katta qiymatnio qaytaradi
# print(min(1,3,8)) #eng kichik qiymatnio qaytaradi
# print(sum([1,3,8])) # berilgan sonlar yigindisini hisoblash
# print(sum((1,3,8)))
# p = math.pi # 3.14 , pi soni
# print(p)
# e = math.e
# print(e)
# n = 12.3
# print(math.ceil(n)) # tepaga qarab sonni yaxlitledi
# print(math.floor(n)) # pastga qarab sonni yaxlitledi
# print(math.pow(10,2)) # 10 ** 2 >> kvadrat olish
# print(math.pow(2,2)) # 2 ** 2
import random
#r = random.random()
#print(r) # 0.0 , 1.0 >> tasodifiy bitta son
# rn = random.randint(0,10) # 2 ta butun son orasida bitta tasodifiy son qaytadi
# print(rn)
# s = "salom"
# print(random.choice(s))#tasodifiy bitta belgi ketma ketlig ichidan
# arr = [1,2,3,4,5]
# random.shuffle(arr)# List elementlarini qorishtirish
# print(arr)

# s = "Hello World"
# print(random.sample(s,3)) # siz korsatgan massivdan siz korsatgan miqdorda tasodifiy elementlarni qaytaradi