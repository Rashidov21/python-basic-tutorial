# if 10 > 5: # True >> Agar
#     print('True')
# elif 5 < 10: # True >> Yoki
#     print('True')
# else: # Faqat False bo'lganda ishledi >> Aks holda
#     print('False')
# x = int(input('Yoshiz >>>'))
# if x > 18:
#     print('Welcome \a')
# elif x == 18:
#     print('Rosa paytizakan ...')
# else:
#     print('Mumkinmas \a')
# fruits = input('Meva')
# if fruits:
#     if fruits.lower().startswith('a'):
#         print('A harfi bor')
#     if fruits.lower().startswith('b'):
#         print('B harfi bor')
#     if fruits.lower().startswith('c'):
#         print('C harfi bor')
# else:
#     print('Boshqa harflar bor...')



#1. inputda t harfi bormi yoqmi tekshiring , agar bosa bor deng bomasa
# yoq deng

#2. son qabul qiling juft yoki toq ekanini aniqlang

#3. OS nomlarini qabul qiling, agar windows bosa Microsoft
# linux bosa Ubuntu , macOs bosa Apple sozlarini print qiling

n = 10
if "t" in n:
    print("Ha")
else:
    print("YO")

# print("XA" if len(n) > 5 else "YOQ")










# op = input('1-5 orasida son kiriting')
# if op != '':
#     if op == '1':
#         print('Windows')
#     elif op == "2":
#         print('Ubuntu')
#     elif op == '3':
#         print('MacOS')
#     elif op == '4':
#         print('Windows XP')
#     else:
#         print('Boshqa OP')
# else:
#     print('Bu son emas !')
# x = input()
# x = int(x)
# a = "Yes" if x == 5 else "No"
# print(a)