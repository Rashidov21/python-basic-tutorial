# map and filter

# Map function
# print(list(map(lambda x : x**2, list(range(5))))) #[0, 1, 4, 9, 16]
# Filter function
# print(list(filter(lambda x: x > 0, [-1, 1, -2, 2, 0]))) #[1, 2]
# print(list(filter(lambda x: len(x) == 2, ["a", "aa", "b", "bb"]))) # ['aa', 'bb']
# print([x for x in [0,2,-1,-6,5] if x > 0])


# Standart Functions
# source https://letpy.com/handbook/builtins/
# All
# print(all([0,1,2,0])) # False
#
# print(any([False, 0, 1])) # True
#
# print(abs(-1)) # 1
#
# print(chr(12)) #j
# print(ord('h')) # 23

# int(), float(), str(), bool()
# list(), dict(), tuple(), set(),frozenset()
# getattr(). setattr(), delattr(), hasattr()
# enumerate(), format(), len(),pow(2,10),
# reversed(), sorted(),, sum(), super()
# max(), min(), range(), open()

# cards = list(range(2,14))
# Python program to find the sum of natural using recursive function

# Python program to find the sum of natural using recursive function

# def recur_sum(n):
#    if n <= 1:
#        return n
#    else:
#        return n + recur_sum(n-1)
#
# # change this value for a different result
# num = 16
#
# if num < 0:
#    print("Enter a positive number")
# else:
#    print("The sum is",recur_sum(num))

# l = [61,228,9]# >> 961228 > 986221
#
# s = "aaabbbbcceeeeeeeeeeb"
# true_s = "a2b3c1e6b"


